# Componentes que puedes usar

Estos son los componentes `sk-*` del kit. Vienen del bundle `sk-components-elements.js` como *custom elements*: se usan como etiquetas HTML en cualquier framework o sin ninguno.

**Usa solo los componentes de esta lista.** El bundle registra otros, pero no son parte de la prueba. Si necesitas algo que no está aquí, decide si es un token, una variante o un componente nuevo, constrúyelo con los tokens de `tokens.css` y explícalo en `DECISIONES.md`.

## Cómo leer esta referencia

- **attr**: atributo en kebab-case en el HTML (`sk-type="secondary"`).
- **prop**: propiedad que se asigna por JavaScript (`el.visible = true`).
- Eventos: `el.addEventListener('nombre', (e) => e.detail)`.
- Los valores entre `|` son las opciones; la primera es la predeterminada.

| Componente | Para qué |
|---|---|
| `sk-logo` | Logo de Skandia |
| `sk-button` | Acciones |
| `sk-input-text` | Texto de una línea |
| `sk-textarea` | Texto largo |
| `sk-card` | Agrupar contenido en una superficie |
| `sk-alert` | Avisos dentro de la página |
| `sk-tag` | Etiquetas de estado (decorativas) |
| `sk-modal` | Diálogos |
| Pestañas (`.sk-tabs-r`) | Navegar entre vistas de un mismo contenido |

---

## sk-logo

`variant` logo|isotipo|isotipo-simple · `sk-style` color|verde|negro|blanco (blanco sobre fondos oscuros o de color) · `decorativo` (si al lado ya dice "Skandia") · `aria-label`.
Alto natural 48 px; cambia el tamaño con `style="height: 34px"`. No es interactivo. Nunca dibujes el logo a mano.

```html
<sk-logo style="height: 34px"></sk-logo>
```

## sk-button

`label` · `sk-type` primary|secondary|tertiary · `size` large|small · `icon` (`pi pi-*`) · `icon-pos` left|right · `disabled` · `loading` · `type` button|submit|reset · `aria-label` (obligatorio si no hay `label`).
Eventos: `skClick`.

```html
<sk-button label="Continuar" icon="pi pi-arrow-right" icon-pos="right"></sk-button>
<sk-button label="Volver" sk-type="secondary"></sk-button>
```

Una sola acción principal (`primary`) por zona.

## sk-input-text

`label` (flotante) · `placeholder` · `help-text` · `error-message` · `icon-left` · `icon-right` · `size` md|sm|lg · `type` text|tel|email|password|url|search · `clearable` · `readonly` · `disabled` · `required` · `value`.
Eventos: `valueChange`, `skChange` → texto, `skFocus`, `skBlur`.

```html
<sk-input-text label="Nombre del proyecto" help-text="Lo puedes cambiar después"></sk-input-text>
```

No hay validadores: lee `el.value` y muestra el error con `el.errorMessage = 'Texto del error'`. Vacíalo cuando se corrija.

## sk-textarea

`label` (arriba) · `placeholder` · `help-text` · `error-message` · prop `rows` (5) · `auto-resize` · prop `maxLength` · `show-char-count` (requiere `maxLength`) · `readonly` · `disabled` · `required` · `value`.
Eventos: **solo** `valueChange`, `skFocus`, `skBlur` (no emite `skChange`).

```html
<sk-textarea label="Describe lo que necesitas" auto-resize></sk-textarea>
```

## sk-card

`header` · `subheader`. El cuerpo va como hijos.
`header` no es un título semántico: si la tarjeta abre una sección, pon un `<h3>` real en el cuerpo. No es clicable ni seleccionable. Nunca pongas una tarjeta dentro de otra.

```html
<sk-card header="Resumen" subheader="Actualizado hoy">
  <p>Contenido de la tarjeta.</p>
</sk-card>
```

## sk-alert

`type` info|success|warning|error · `title` (opcional) · `message` · `closable` (true; `"false"` para avisos fijos) · `visible`.
Eventos: `skClose`, `visibleChange`. Usa `warning` y `error` solo si es urgente: se anuncian a lectores de pantalla como alerta.

```html
<sk-alert type="info" title="Antes de seguir" message="Revisa este punto." closable="false"></sk-alert>
```

## sk-tag

`sk-style` info|success|warning|error · `size` large|small · `show-icon` + `icon`. El texto va como hijo. Es decorativo: no lleva acciones.

```html
<sk-tag sk-style="success">Aprobado</sk-tag>
```

## sk-modal

`title` · `size` medium|small|large (600/400/800 px) · `closable` (true; `"false"` quita la X e ignora ESC) · `close-on-escape` · `dismissable-mask` · prop `visible`.
Eventos: `visibleChange`, `opened`, `closed`. El cuerpo y los botones van como hijos. Bajo 576 px ocupa toda la pantalla.

```html
<sk-modal id="detalle" title="Detalle">
  <p>Contenido del modal.</p>
  <sk-button label="Cerrar"></sk-button>
</sk-modal>
<script>document.getElementById('detalle').visible = true;</script>
```

Para un sí/no simple: `await window.skElements.modal.confirm({ title, message, acceptLabel, cancelLabel })` → `true | false`.

## Pestañas (`.sk-tabs-r`)

El bundle no registra `sk-tabs`. La plantilla trae un reemplazo con los estilos reales y el comportamiento de teclado (←/→, Home/End): estructura `role="tablist"` + botones `role="tab"` + paneles `role="tabpanel"`. Copia el bloque de `plantilla.html`.

---

## Reglas de uso en HTML

1. **Monta la UI cuando el bundle esté listo.** Pon los `sk-*` dentro de un `<template>` y móntalos tras `customElements.whenDefined('sk-button')`. Si los escribes directo en el `<body>`, sus hijos quedan fuera del componente. Ver `plantilla.html`.
2. **Atributos en kebab-case; datos complejos por propiedad JS**, antes de montar.
3. **No escribas CSS para "arreglar" un componente.** Si algo se ve mal, casi siempre es un atributo mal escrito o un hijo fuera del componente.
4. **Para tu layout usa los tokens** de `tokens.css`. Nada de hex sueltos.
5. **En React u otro framework:** los atributos de texto funcionan igual; los eventos se escuchan con `addEventListener` sobre una `ref`.

El bundle se carga desde internet y se publica sin versión: necesitas conexión.
