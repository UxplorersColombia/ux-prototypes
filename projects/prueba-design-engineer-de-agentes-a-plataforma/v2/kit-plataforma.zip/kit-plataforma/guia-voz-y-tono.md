# Guía de voz y tono (fragmento)

Este es el fragmento de la guía de comunicación de Skandia que necesitas para escribir el microcopy de tu plataforma. Aplica a los textos de la interfaz, no solo a los que generan las capacidades.

## Lo que debe sentir la persona

> Toda interacción debe dejar a la persona con una sensación de tranquilidad, información clara y seguridad sobre cada decisión que está tomando.

| Sensación | Qué significa |
|---|---|
| Tranquilidad | Sin urgencia artificial. Sin dramatizar consecuencias. |
| Orientación clara | Explicamos qué ocurre. Contexto antes de pedir una acción. |
| Acompañamiento respetuoso | La decisión siempre es de la persona. |
| Comprensión antes que acción | Primero entender y ver opciones, luego actuar. |
| Seguridad y respaldo | Lenguaje sobrio y responsable. Nada suena improvisado. |
| Autonomía | Opciones visibles. Salidas claras. Cambiar de opinión es válido. |

**Nunca debe sentirse:** presión o prisa, juicio, miedo a equivocarse, venta insistente ni lenguaje alarmista.

## La voz

| Atributo | Descripción |
|---|---|
| Cercana, pero profesional | Cálida, respetuosa y preparada. |
| Clara, sin tecnicismos | Palabras sencillas. Lo complejo, explicado sin hacerlo pesado. |
| Segura, sin autoritarismo | Confianza y conocimiento, sin imponer. |
| Empática, sin dramatizar | Reconoce el contexto y mantiene la calma. |
| Orientada al futuro | Muestra el para qué. |

| En vez de | Escribe |
|---|---|
| "Debe actualizar su información para evitar inconsistencias." | "Te invitamos a actualizar tu información para que podamos acompañarte mejor." |
| "Adjuntamos los datos correspondientes a tu saldo." | "Aquí encuentras tu saldo, explicado paso a paso." |

## Reglas de escritura

- Frases cortas. Una idea principal por frase.
- Sin jerga. Si usas un término técnico, explícalo con un ejemplo.
- Primero el concepto, luego las cifras.
- Voz activa.
- Orden: contexto → información clave → qué sigue.
- **Verbos que invitan:** puedes, tienes la opción de, aquí verás, conoce, revisa, explora.
- **Verbos a evitar:** te recomendamos, te sugerimos, te conviene, deberías, lo ideal es.

## Persona gramatical e inclusividad

- Siempre **tú**. Nunca "usted" ni "el usuario" como construcción impersonal.
- Evita el masculino genérico: "Te damos la bienvenida" en vez de "Bienvenido".

## Extensión

| Contenido | Guía |
|---|---|
| Títulos | 5 a 8 palabras. Directos, centrados en la acción o el beneficio. |
| Descripciones | 1 a 2 frases: el qué y el para qué. |
| Mensajes informativos | Máximo 3 ideas. Contexto → dato → acción. |
| Confirmaciones | Una frase clara + qué sigue. |

## Tono según el momento

| Momento | Tono | Ejemplo |
|---|---|---|
| Error o bloqueo | Preventivo: contener, guiar y resolver | "Parece que algo no salió bien. Puedes intentarlo de nuevo o volver más tarde." |
| Consulta | Informativo: explicar sin sobrecargar | "Esto es lo que encontramos y de dónde sale." |
| Algo nuevo | Educativo: ayudar a entender el valor | "Con esta opción puedes ver el resultado antes de decidir." |
| Éxito | Transaccional: confirmar y decir qué sigue | "Listo. Tu resultado está guardado. Puedes compartirlo o ajustarlo." |

## Datos

- Explica por qué se usa un dato y cómo ayuda a la persona.
- Nunca des a entender que se observa la actividad de la persona.
- Recuerda que los datos están protegidos, sin mensajes defensivos.

| Escribe | Evita |
|---|---|
| "Usamos esta información para mostrarte opciones que se alineen con tu necesidad." | "Tu comportamiento indica que deberías…" |
| "Puedes modificar esta información cuando quieras." | Mensajes que generen sensación de vigilancia |

## Lo legal

- Lo legal informa, no intimida.
- Va al final, como complemento. Nunca justo después del título o del botón.
- En digital, puede ir como contenido expandible ("Ver más", "Información legal").
- Explica los riesgos de forma honesta y orientada a entender.
