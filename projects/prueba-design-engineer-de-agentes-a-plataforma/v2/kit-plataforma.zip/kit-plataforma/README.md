# Kit de la prueba · De agentes a plataforma

Este kit acompaña el documento de la prueba (`prueba-design-engineer.md`). Trae lo que necesitas para construir tu plataforma sin conocer Skandia por dentro.

> **Confidencial.** Recibes este kit bajo el acuerdo de confidencialidad de la prueba. No lo publiques ni lo compartas.
> [Texto del acuerdo: lo aporta el área jurídica]

## Qué hay adentro

```
kit-plataforma/
├── README.md                  ← este archivo
├── capacidades.json           ← contrato de las 5 capacidades + respuestas simuladas
├── encargos-de-ejemplo.json   ← necesidades para probar los estados obligatorios
├── personas/
│   ├── persona-a-product-owner.md
│   ├── persona-b-ejecutivo-comercial.md
│   └── persona-c-analista-cumplimiento.md
├── design-system/
│   ├── componentes.md         ← los componentes sk-* que puedes usar
│   ├── tokens.css             ← colores, tipografía, espaciado, sombras, movimiento
│   └── plantilla.html         ← página de ejemplo que monta los componentes
└── guia-voz-y-tono.md         ← fragmento de la guía de comunicación
```

## Cómo usar `capacidades.json`

- Cada capacidad tiene su **contrato**: qué recibe, qué entrega, cuánto suele tardar, si necesita revisión humana y de qué otras capacidades depende.
- Todas responden con el mismo sobre (`contratoComun`): `estado`, `evidencia` con sus `fuentes`, `contenido`, `advertencias` y `siguientesCapacidades`. Si algo falla, responden con `estado: "error"` y un `error.codigo`.
- Cada capacidad trae **tres respuestas simuladas**:
  - `normal`: el camino esperado.
  - `evidenciaDebil`: un resultado que se puede usar, pero con poco respaldo.
  - `error`: una falla. El `mensaje` es técnico a propósito: no está pensado para mostrarse tal cual.
- Las respuestas simuladas siguen el encargo de la persona A (simulador de aportes).
- Las duraciones son las de referencia. En tu simulación puedes acortarlas, pero tu interfaz tiene que poder manejar las reales.
- Puedes cambiar o ampliar el contrato si lo necesitas. Explica por qué en `DECISIONES.md`.

### Evidencia real y sintética

Todo el contenido del kit es inventado para la prueba. **Dentro de la ficción:**

- Las fuentes `cualitativa`, `cuantitativa`, `benchmark` y `lineamiento` representan evidencia real.
- Las fuentes `sintetica` vienen de usuarios simulados por IA.
- Las fuentes `generada` son contenido que la IA produjo a partir de otras salidas.
- `esSintetica: true` marca lo que no tiene respaldo en personas reales.

## Cómo usar `encargos-de-ejemplo.json`

Son necesidades escritas como las escribiría cada persona. Cada una indica qué caso prueba: éxito, necesidad ambigua o datos sensibles, más los encargos de las personas B y C.

Los nombres, cédulas, correos y saldos son **ficticios**. Están ahí para que compruebes que tu plataforma los detecta y no los envía.

## Cómo usar el Design System

1. Abre `design-system/plantilla.html` con un servidor local (por ejemplo `npx serve design-system` o `python -m http.server`). Algunos navegadores bloquean `file://`.
2. Lee `design-system/componentes.md`: ahí están los componentes que puedes usar y sus atributos.
3. Usa `tokens.css` para tu propio layout y para lo que construyas fuera de los componentes.

Los componentes se cargan desde internet (`sk-components-elements.js`): necesitas conexión.

## Reglas

- Usa solo los datos del kit. No pongas datos reales de Skandia ni de clientes en ningún servicio de IA externo.
- Nunca subas tu llave de API al repositorio.
- No publiques el kit.
