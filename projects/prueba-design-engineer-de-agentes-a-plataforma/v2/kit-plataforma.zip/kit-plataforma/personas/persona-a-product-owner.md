# Persona A · Product Owner de un producto de inversión

> Persona ficticia, creada para la prueba. **Construye el flujo completo para esta persona.**

## Su necesidad

"Quiero saber si vale la pena un simulador de aportes antes de pedirle un sprint a desarrollo."

## Contexto

- Es responsable del Fondo Voluntario de Pensiones en la app.
- Tiene un backlog lleno y un equipo de desarrollo con sprints de dos semanas.
- Le llegan ideas de varias áreas y tiene que decidir cuáles merecen un sprint.
- Hoy, para validar una idea, le escribe al equipo UX y espera su turno.

## Lo que sabe

- Conoce bien el producto, sus reglas y a sus clientes.
- Sabe priorizar un backlog y escribir historias de usuario.
- Usa herramientas digitales todos los días (correo, Teams, Jira, Excel).

## Lo que no sabe

- No sabe qué es un PRD ni cómo se valida un concepto.
- No sabe qué hace cada capacidad ni en qué orden usarlas.
- No sabe distinguir una evidencia sólida de una débil.

## Qué sería un buen resultado

- Una respuesta clara para decidir: hacerlo, no hacerlo o validarlo primero.
- Algo que pueda mostrarle a su jefe y a desarrollo.
- Saber qué tan confiable es esa respuesta.

## Qué le frustra

- Esperar semanas por una respuesta.
- Documentos largos llenos de jerga.
- Que le digan "depende" sin decirle de qué depende.
