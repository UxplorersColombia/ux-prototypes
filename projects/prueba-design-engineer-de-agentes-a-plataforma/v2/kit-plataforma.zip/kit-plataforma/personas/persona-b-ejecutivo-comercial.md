# Persona B · Ejecutivo comercial

> Persona ficticia, creada para la prueba. Explica en `DECISIONES.md` cómo la atendería tu plataforma.

## Su necesidad

"Necesito explicarle un producto nuevo a clientes que están por pensionarse."

## Contexto

- Atiende una cartera de clientes y pasa buena parte del día en reuniones y llamadas.
- Prepara presentaciones y mensajes para sus clientes; casi siempre parte de material de mercadeo.
- Trabaja desde el celular entre reuniones.

## Lo que sabe

- Conoce a sus clientes, sus preocupaciones y cómo hablarles.
- Sabe vender y explicar productos en persona.

## Lo que no sabe

- No sabe qué capacidad usar ni qué es un segmento.
- No conoce el proceso de diseño ni sus términos.

## Qué sería un buen resultado

- Un mensaje claro que pueda usar con sus clientes esta misma semana.
- Saber que el mensaje cumple con la forma de hablar de Skandia.

## Qué le frustra

- Formularios largos antes de obtener algo útil.
- Tener que explicar varias veces lo que necesita.
