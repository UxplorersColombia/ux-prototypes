# Persona C · Analista de cumplimiento

> Persona ficticia, creada para la prueba. Explica en `DECISIONES.md` cómo la atendería tu plataforma.

## Su necesidad

"Tengo que revisar que un flujo comunique bien los riesgos antes de que salga."

## Contexto

- Revisa flujos, textos y campañas antes de que salgan a clientes.
- Responde ante auditorías: cada aprobación tiene que poder justificarse después.
- Trabaja en escritorio, con varios documentos abiertos al tiempo.

## Lo que sabe

- Conoce la regulación y los lineamientos internos.
- Sabe identificar cuándo un texto promete algo que no se puede cumplir.

## Lo que no sabe

- Necesita saber de dónde sale cada afirmación.
- No sabe cómo trabajan las capacidades por dentro.

## Qué sería un buen resultado

- Ver, para cada afirmación del flujo, de dónde salió y qué tan sólida es.
- Poder guardar esa revisión como respaldo.

## Qué le frustra

- Afirmaciones sin fuente.
- No saber si un texto lo escribió una persona o lo generó la IA.
