# Content Strategy — Login_Dash_App
**Fecha:** 2026-06-11
**Content Designer:** Kiki · UX Content · Skandia UX Team
**Canales:** App móvil (iOS/Android)
**Segmentos:** Clientes existentes con productos activos — perfil predominante 30–39 años

---

## Voz y tono para este proyecto

Skandia en la app móvil suena como un asesor financiero que te conoce: directo, claro y sin rodeos, pero siempre con respaldo. No habla de inversión como si fuera complicado — habla de tu dinero como si fuera exactamente eso: tuyo. En el login, el tono es funcional y eficiente, porque el usuario solo quiere entrar. En el home, es orientador y tranquilizador: confirma que todo está en orden y señala qué hay que atender. No celebra en exceso, no alarma sin razón. Cuando algo falla, explica qué pasó y dice exactamente qué hacer — sin culpar al usuario, sin tecnicismos, sin vaguedad. La coherencia de tono entre la app y el portal web no es opcional: es parte de la confianza de marca.

---

## Promesa central

> "Tu dinero está aquí, claro y disponible — en los mismos segundos que tienes para revisarlo."

---

## Mensajes clave

1. **Entrar es fácil.** Tu huella o tu cara son suficientes. Si algo falla, sabes exactamente qué hacer.
2. **Ves todo de un vistazo.** Tu saldo total y tus productos activos están en la primera pantalla — sin buscar, sin navegar.
3. **Sabes cómo vas, no solo cuánto tienes.** El home no solo muestra cifras: muestra si tus inversiones avanzan o no.
4. **Skandia es uno solo.** La app y el portal se sienten iguales — porque son el mismo producto.
5. **Lo que viniste a hacer, lo puedes hacer rápido.** Las acciones más frecuentes están a un toque desde el inicio.

---

## Vocabulario

### Palabras que usamos

| Usamos | Porque |
|---|---|
| tú / tu | Es el registro de la app móvil. Cercano sin ser informal. |
| saldo consolidado | Refleja la posición total del usuario — es el término que el usuario ya usa. |
| portafolio | Vocabulario natural en el contexto de inversión. No asustar, pero tampoco simplificar de más. |
| rentabilidad | Es la palabra que los usuarios piden ver en verbatims — "no se ven las rentabilidades". |
| acceder / ingresar | Verbos claros para el flujo de login. |
| configurar | Para acciones de ajuste sin tono técnico. |
| Fondos Mutuos · Pensión & Cesantías · Seguros · Crédito | Nomenclatura oficial del portal — se mantiene sin excepción. |
| ocultar / mostrar | Para la privacidad del saldo. Acciones concretas, fáciles de leer. |
| verificar | Para momentos de confirmación biométrica o de identidad. |

### Palabras que evitamos

| Evitamos | Usamos en cambio |
|---|---|
| autenticación | ingresar / acceder / verificar tu identidad |
| credenciales | contraseña / huella / Face ID |
| biometría (en UI) | huella digital / reconocimiento facial |
| usuario (como campo) | número de cédula |
| portal / web (en la app) | — (no referenciamos otros canales desde la app) |
| Continuar (solo) | Ingresar con huella / Ver mi saldo / Acceder a mi cuenta |
| Error (sin contexto) | Descripción directa de qué pasó |
| ¡Bienvenido! (exclamativo vacío) | Hola, [Nombre] (saludo funcional y personalizado) |
| rendimientos (forma genérica) | rentabilidad / rendimiento de [nombre del producto] |
| gestión | depende del contexto: revisar / mover / aportar |
| usted | tú (sin excepción en app móvil) |

---

## Lo que NO decimos

**Por regulación o pending de validación legal:**
- No prometemos rendimientos ni proyecciones de desempeño sin disclaimers validados por Legal/Compliance.
- No afirmamos que un producto "es seguro", "no tiene riesgo" o "garantiza rentabilidad".
- No usamos comparativos ("el mejor", "el más rentable") sin respaldo de datos auditados.
- No nombramos a la competencia en ningún mensaje in-app.
- Cualquier mensaje relacionado con autenticación biométrica que implique promesas de seguridad debe pasar por revisión legal antes de producción.

**Por tono:**
- No generamos urgencia artificial ("Solo por hoy", "No pierdas esta oportunidad").
- No usamos jerga financiera que requiera glosario para entenderse.
- No celebramos con exceso emocional en contextos funcionales (errores, acceso, saldo).
- No culpamos al usuario en mensajes de error ("Ingresaste mal tu contraseña" → "No reconocemos esta contraseña").
- No ignoramos el estado emocional del usuario que lleva minutos intentando entrar — los errores de login deben ser los más claros y los más empáticos de toda la app.

**Por scope del proyecto:**
- No comunicamos beneficios de flujos operativos (aportes, retiros, traslados) en esta fase — solo facilitamos el acceso a ellos.
- No invitamos a abrir productos nuevos desde pantallas de login o saldo sin que el usuario lo haya solicitado implícitamente (banners solo post-scroll y solo para segmentos con oportunidad identificada).

---

## Arquitectura de mensajes por pantalla

---

### Pantalla 1 — Login con biometría (ruta principal)

**Propósito:** Que el usuario entre a la app en el menor número de pasos posibles. La biometría es la ruta por defecto — no una opción secundaria. El usuario no debe escribir nada si su biometría está activa.

| Elemento | Texto propuesto | Nota |
|---|---|---|
| Título | "Hola de nuevo" | Cálido, breve. No usa el nombre porque aún no hay sesión activa. |
| Subtítulo | "Usa tu huella o tu rostro para ingresar" | Indica el método sin tecnicismos. En iOS adaptar a "Face ID o huella digital". |
| CTA principal | "Ingresar con huella digital" / "Ingresar con Face ID" | El botón llama a la acción biométrica específica según el dispositivo. |
| Microcopy de apoyo | "¿Prefieres usar tu contraseña?" (enlace secundario) | Visible pero subordinado al CTA principal. |
| Microcopy de apoyo | Ícono de huella / Face ID centrado en pantalla | El ícono activa el lector automáticamente al abrir la app. |
| Error (si aplica) | "No reconocemos tu huella. Intenta de nuevo o ingresa con tu contraseña." | 🟡 Validar con Legal si aplica |

---

### Pantalla 2 — Login con contraseña (fallback)

**Propósito:** Dar acceso seguro cuando la biometría no está disponible o falla. El campo de usuario debe estar correctamente etiquetado — este es el punto de mayor fricción identificado en verbatims de pasivos ("no tenía claro que el usuario es el número de cédula").

| Elemento | Texto propuesto | Nota |
|---|---|---|
| Título | "Ingresa a tu cuenta" | Directo y funcional. |
| Subtítulo | — | No es necesario en esta pantalla; los campos y labels son suficiente. |
| Label campo 1 | "Número de cédula" | Explícito. Elimina la confusión cédula vs. correo reportada en verbatims. |
| Placeholder campo 1 | "Ej. 1023456789" | Formato real para confirmar que es la cédula, no el correo. |
| Label campo 2 | "Contraseña" | Simple y directo. |
| Placeholder campo 2 | — | No usar placeholder en campos de contraseña por accesibilidad. |
| Toggle visibilidad | "Mostrar contraseña" + ícono de ojo | Texto + ícono — mejor accesibilidad para segmentos 50+ (Elite, Elite Wealth, edad promedio 54–62 años). No usar solo el ícono. |
| CTA principal | "Ingresar" | En esta pantalla el beneficio es implícito — la acción es el contexto. |
| Microcopy de apoyo | "¿Olvidaste tu contraseña?" (enlace) | Visible justo debajo del campo de contraseña — donde el usuario lo busca. |
| Microcopy de apoyo | "¿Tienes huella o Face ID? Actívalo aquí" | Solo visible si el usuario no tiene biometría configurada. |
| Error (si aplica) | "No reconocemos esta contraseña. Verifica que el bloqueo de mayúsculas esté desactivado e inténtalo de nuevo." | 🟡 Validar con Legal si aplica |

---

### Pantalla 3 — Estados de error de autenticación

**Propósito:** Informar al usuario exactamente qué pasó y qué debe hacer, sin generar ansiedad adicional. Este es el momento de mayor riesgo de abandono — el copy debe ser el más claro de toda la app.

**Principio de escritura para errores:** Qué pasó (una frase) + qué hacer ahora (una acción concreta). Sin culpar. Sin tecnicismos. Sin vagas disculpas.

| Elemento | Texto propuesto | Nota |
|---|---|---|
| **Error A — Contraseña incorrecta (1.° intento)** | | |
| Título error | "No reconocemos esta contraseña" | No dice "Contraseña incorrecta" — no culpa al usuario. |
| Descripción | "Verifica que el bloqueo de mayúsculas esté desactivado e inténtalo de nuevo." | La causa más frecuente primero. |
| CTA | "Intentar de nuevo" | |
| Enlace secundario | "¿Olvidaste tu contraseña?" | |
| **Error B — Contraseña incorrecta (3.° intento / bloqueo inminente)** | | |
| Título error | "Un intento más y tu cuenta se bloqueará" | Advertencia sin alarmar. |
| Descripción | "Si olvidaste tu contraseña, puedes recuperarla ahora y evitar el bloqueo." | Propone la salida antes de que ocurra el problema. |
| CTA principal | "Recuperar mi contraseña" | Orienta hacia la solución. |
| CTA secundario | "Intentar de nuevo" | |
| **Error C — Cuenta bloqueada** | | |
| Título error | "Tu cuenta está bloqueada temporalmente" | "Temporalmente" reduce la ansiedad — no es permanente. |
| Descripción | "Esto ocurre después de varios intentos fallidos. Puedes desbloquearla en menos de dos minutos." | Normaliza el problema y anticipa la solución. |
| CTA principal | "Desbloquear mi cuenta" | |
| **Error D — Error técnico / app no responde** | | |
| Título error | "Algo falló de nuestro lado" | Asume responsabilidad sin culpar al usuario. |
| Descripción | "Estamos trabajando para resolverlo. Espera unos minutos e inténtalo de nuevo." | |
| CTA | "Intentar de nuevo" | |
| Microcopy | "Si el problema persiste, contáctanos." (enlace a soporte) | 🟡 Validar URL / canal de soporte con el equipo |
| **Error E — Biometría bloqueada** | | |
| Título error | "Tu huella digital está bloqueada" | Específico — el usuario sabe exactamente qué falló. |
| Descripción | "Esto puede ocurrir después de varios intentos fallidos. Ingresa con tu contraseña para desbloquearla." | Ofrece la ruta alternativa de inmediato. |
| CTA principal | "Ingresar con contraseña" | |
| Microcopy | "¿Necesitas ayuda?" (enlace a soporte) | 🟡 Validar con Legal si aplica |
| **Error F — Sesión cerrada por inactividad** | | |
| Título error | "Cerramos tu sesión para proteger tu cuenta" | Empático y asume responsabilidad — no culpa al usuario. Adaptado de Nubank a la voz profesional de Skandia. 🟡 Revisar con Legal el copy exacto |
| Descripción | "Detectamos que tu sesión estuvo inactiva por un tiempo. Es una medida de seguridad automática." | Normaliza el evento — no es un fallo técnico, es protección. |
| CTA principal | "Ingresar con huella digital" / "Ingresar con Face ID" | Biometría como primera opción de re-entrada — coherente con la jerarquía del flujo principal. |
| CTA secundario | "Ingresar con contraseña" | Alternativa cuando la biometría no está disponible. |

---

### Pantalla 4 — Recuperación de acceso

**Propósito:** Que el usuario recupere el acceso en el menor número de pasos. El copy debe transmitir que el proceso es corto y controlado — no un trámite.

**Paso previo — bottom sheet de advertencia (antes de iniciar el flujo)**

Antes de que el usuario entre al flujo de recuperación, un bottom sheet gestiona sus expectativas y evita que abandone a mitad del proceso.

| Elemento | Texto propuesto | Nota |
|---|---|---|
| Título bottom sheet | "Para recuperar tu acceso, necesitarás:" | Introduce los requisitos antes de que el usuario empiece. |
| Cuerpo | "· Tu número de cédula\n· Acceso al correo o celular registrado en tu cuenta" | Lista concisa de lo que necesita el usuario. |
| Advertencia | "Saldrás del flujo actual y comenzarás el proceso de recuperación." | Anticipa el cambio de contexto — reduce la sorpresa y el abandono a mitad del proceso. Inspirado en el patrón de Nubank. |
| CTA principal | "Continuar con la recuperación" | Acción afirmativa + contexto de hacia dónde va. |
| CTA secundario | "Cancelar" | Permite al usuario volver atrás sin consecuencias. |

**Flujo principal de recuperación**

| Elemento | Texto propuesto | Nota |
|---|---|---|
| Título | "Recupera el acceso a tu cuenta" | Orientado al resultado, no al problema. |
| Subtítulo | "Te enviamos un código a tu correo o celular registrado para verificar tu identidad." | Explica qué va a pasar antes de que pase. |
| Label campo | "Número de cédula" | Mantiene coherencia con la pantalla de login. |
| CTA principal | "Enviar código de verificación" | Acción + contexto de qué recibirá el usuario. |
| Confirmación de envío | "Revisá tu correo o tu celular. El código llega en menos de un minuto." | Gestiona la espera con una expectativa concreta. |
| Error — código incorrecto | "Este código no es válido. Verifica que lo hayas copiado correctamente o solicita uno nuevo." | |
| Error — código expirado | "Este código ya expiró. Solicita uno nuevo para continuar." | |
| CTA reenvío (inactivo, durante countdown) | "Podés pedir otro código en [X] segundos" | Estado deshabilitado con contador regresivo. El tiempo real debe confirmarse con el equipo técnico. 🟡 Confirmar duración del countdown con el equipo técnico |
| CTA reenvío (activo, después del countdown) | "Pedir otro código" | Se habilita al llegar a cero. Acción directa sin fricción adicional. |
| Hint debajo del CTA de reenvío | "(Revisá también tu carpeta de correo no deseado)" | Reduce los contactos a soporte por código no recibido. Inspirado en Trii. |
| Microcopy de apoyo | "¿No recibes el código? Verifica que el correo y el celular registrados sean los correctos." | 🟡 Validar flujo de actualización de datos de contacto |
| Éxito — nueva contraseña creada | "Listo. Tu nueva contraseña está activa. Puedes ingresar ahora." | Cierra el flujo con confirmación clara. |
| CTA post-éxito | "Ingresar a mi cuenta" | |

---

### Pantalla 5 — Home: saludo y saldo consolidado

**Propósito:** Dar al usuario su posición financiera completa en los primeros segundos. La mediana de sesión es 86 segundos — el home debe entregar valor en los primeros 10. Esta es la pantalla más importante del flujo post-login.

| Elemento | Texto propuesto | Nota |
|---|---|---|
| Saludo | "Hola, [Nombre]" | Nombre de pila, sin apellido. Cálido y rápido. |
| Saldo total | "$[monto] COP" | Formato de moneda consistente con el portal. |
| Label saldo | "Tu saldo total" | Simple. No "saldo consolidado" en la UI — es jerga. |
| Toggle privacidad | "Ocultar saldo" / "Mostrar saldo" | Los íconos estándar (ojo abierto / cerrado) acompañan el texto. |
| Subtexto saldo | "Suma de todos tus productos activos" | Explica qué incluye el número para el usuario que tiene 2+ productos. |
| Microcopy fecha | "Actualizado hoy a las [HH:MM]" | Confirma que el dato es vigente — reduce la desconfianza en el número. |
| Error — saldo no disponible | "No pudimos cargar tu saldo ahora mismo. Intenta recargar." | |
| CTA error | "Recargar" | |

---

### Pantalla 6 — Tarjeta de producto: 1 producto (caso principal — Fondos Mutuos, 69,2 % de usuarios)

**Propósito:** El usuario con un solo producto necesita más contexto en esa tarjeta. No solo "cuánto tienes" sino "cómo vas". Los verbatims lo piden explícitamente: "No es claro cómo cada portafolio está performando."

| Elemento | Texto propuesto | Nota |
|---|---|---|
| Label categoría | "Inversión" | Nomenclatura oficial — no cambiar. |
| Nombre del producto | "Fondos Mutuos" | Nombre del producto como aparece en el portal. |
| Saldo del producto | "$[monto] COP" | |
| Label rentabilidad | "Rentabilidad del mes" | El período más visible primero. Permite expandir a histórico. |
| Valor rentabilidad | "+[X,XX] %" o "−[X,XX] %" | Color verde / rojo del Design System. Sin texto adicional si el ícono es claro. |
| Microcopy rentabilidad | "Respecto al mes anterior" | Contexto para entender el número. |
| CTA principal | "Ver mi portafolio" | Acción + qué encontrará al hacerlo. |
| CTA secundario | "Hacer un aporte" | Acceso directo al flujo de aportes (no se modifica en esta fase). |
| Tooltip rentabilidad | "Este porcentaje refleja el rendimiento de tu fondo en el último mes calendario." | 🟡 Validar cálculo y período con el equipo de datos antes de producción |

---

### Pantalla 7 — Tarjeta de producto: 2 productos apilados

**Propósito:** El 34,2 % de usuarios tiene exactamente 2 productos. Las tarjetas deben permitir comparar de un vistazo sin hacer scroll excesivo ni perder jerarquía.

| Elemento | Texto propuesto | Nota |
|---|---|---|
| Label tarjeta 1 | "Inversión · Fondos Mutuos" | Categoría + nombre de producto en una línea. |
| Label tarjeta 2 | "[Categoría] · [Nombre del producto]" | Mismo formato para ambas tarjetas — consistencia visual. |
| Saldo tarjeta 1 | "$[monto] COP" | |
| Saldo tarjeta 2 | "$[monto] COP" | |
| Rentabilidad tarjeta | "+[X,XX] %" | Solo el dato más reciente. El detalle está un nivel adentro. |
| CTA por tarjeta | "Ver detalle" | Igual en ambas tarjetas — el usuario decide cuál explorar. |
| Microcopy de apoyo | — | En el caso de 2 tarjetas, el saldo consolidado del home ya hace el trabajo de resumen. No repetir. |
| Estado vacío — producto sin datos | "Estamos cargando la información de este producto." | Si un producto no carga, no mostrar tarjeta en blanco. |

---

### Pantalla 8 — Acciones rápidas

**Propósito:** Las 4 acciones más frecuentes deben estar a un toque desde el home — sin scroll, alcanzables con el pulgar. Los CTAs comunican acción + beneficio, no solo el nombre del flujo.

| Elemento | Texto propuesto | Nota |
|---|---|---|
| Acción 1 | "Aportar" | + ícono de suma. Breve porque el contexto (home) lo complementa. |
| Acción 2 | "Retirar" | + ícono de retiro. Idem. |
| Acción 3 | "Mis movimientos" | Preferible a "Historial" — más descriptivo del contenido que encontrará. |
| Acción 4 | "Mis documentos" | Acceso a documentación del usuario. |
| Tooltip / label de sección | "Acciones frecuentes" | Label de sección sobre los botones, no un título de pantalla. |
| Estado deshabilitado | Ícono en gris + "No disponible ahora" | Si un flujo está en mantenimiento — comunica el estado sin eliminar el botón. |
| Microcopy de apoyo | — | En acciones rápidas, el texto debe ser mínimo. El ícono y el label hacen el trabajo. |

---

### Pantalla 9 — Banner contextual (solo para usuarios con oportunidad de cross-sell identificada)

**Propósito:** Comunicar una oportunidad relevante sin interrumpir el flujo principal. El banner aparece siempre después de los productos existentes y solo para segmentos con oportunidad identificada (Joven Pro o superior). Para Finanzas Personales con 1 solo producto: no mostrar.

| Elemento | Texto propuesto | Nota |
|---|---|---|
| Label / etiqueta | "Para ti" | Señala personalización sin prometer lo que no puede cumplir. |
| Título del banner | "Diversifica tu portafolio con Pensión Voluntaria" | Específico al producto sugerido. No genérico. |
| Descripción | "Con tu perfil, podrías aumentar tu rentabilidad a largo plazo. Conoce cómo." | Beneficio concreto. Sin promesas de rendimiento específicas. 🟡 Validar con Legal |
| CTA | "Conocer Pensión Voluntaria" | Acción + nombre del producto. No "Ver más" ni "Conocer más" solos. |
| Microcopy de apoyo | "Esto es una sugerencia basada en tu perfil — no es una recomendación de inversión." | 🟡 Disclaimer regulatorio — validar texto exacto con Legal/Compliance |
| Cerrar banner | Ícono X visible + texto accesible "Cerrar sugerencia" | El usuario debe poder descartarlo sin esfuerzo. |
| Estado — sin oportunidad identificada | No se muestra el banner. | No sustituir con banner genérico de publicidad. |

---

### Pantalla 10 — Estado vacío o categoría sin producto activo

**Propósito:** El 43,6 % tiene 1 solo producto — verá categorías vacías. El estado vacío no debe generar confusión ni sensación de error. Tampoco debe ser una oportunidad de venta agresiva.

| Elemento | Texto propuesto | Nota |
|---|---|---|
| Ícono | Ilustración neutra (no un ícono de error) | Sin colores de alerta. |
| Título | "Todavía no tienes [nombre de categoría]" | Ejemplo: "Todavía no tienes Seguros". Honesto y directo. |
| Descripción | "Cuando tengas un producto de esta categoría, podrás verlo aquí." | Explica la pantalla sin presionar al usuario. |
| CTA (solo si hay oportunidad identificada) | "Conocer [nombre del producto]" | Solo para segmentos con oportunidad. 🟡 Validar con negocio qué productos se promocionan aquí |
| Sin CTA (Finanzas Personales sin oportunidad) | — | No mostrar CTA comercial para este segmento en estado vacío. |
| Microcopy de apoyo | — | El estado vacío no necesita más texto. La simplicidad es la comunicación. |

---

### Pantalla 11 — Movimientos recientes (fragmento en el home)

**Propósito:** Confirmar al usuario el estado de sus transacciones más recientes sin que tenga que navegar. Responde directamente al verbatim: *"No sé si quedó registrada mi solicitud de retiro."*

**Posición en el home:** después de las tarjetas de producto, antes del banner contextual.
**Máximo a mostrar:** 2–3 transacciones. Si no hay movimientos recientes, no mostrar la sección.

| Elemento | Texto propuesto | Nota |
|---|---|---|
| Label de sección | "Movimientos recientes" | Consistente con la acción rápida "Mis movimientos" de Pantalla 8. |
| Estructura por ítem | [Tipo de operación] · [Fecha] · [Monto] · [Estado] | Cuatro datos por fila — el estado es el más importante visualmente. |
| **Estado: Procesada** | | |
| Etiqueta de estado | "Procesada" | Color verde del Design System. Confirma que el movimiento quedó registrado. |
| Ejemplo de ítem | "Retiro · 10 jun · $500.000 COP · Procesada" | |
| **Estado: Pendiente** | | |
| Etiqueta de estado | "En proceso" | Color amarillo/neutro del Design System. Más informativo que "Pendiente" — indica que hay actividad. |
| Ejemplo de ítem | "Aporte · 11 jun · $200.000 COP · En proceso" | |
| **Estado: Rechazada** | | |
| Etiqueta de estado | "No procesada" | 🟡 Validar con el equipo de producto si este es el término que usa el sistema — puede ser "Rechazada", "Fallida" u otro. Evitar "Rechazada" si el sistema no usa ese término exacto. |
| Microcopy de estado rechazado | "Ver qué pasó" (enlace) | Dirige al detalle del movimiento donde se explica la causa. |
| CTA de sección | "Ver todos mis movimientos" | Enlace al historial completo — no sustituye la acción rápida de Pantalla 8. |
| Estado vacío de sección | No mostrar la sección | Si no hay movimientos en los últimos 30 días, omitir el bloque completo. No mostrar estado vacío. |

---

## Coherencia narrativa entre pantallas

**Lo que siente el usuario al abrir la app:**
Reconocimiento inmediato. La app parece la misma que el portal — mismos colores, mismas palabras, mismo registro. No tiene que reaprender nada. Si tiene biometría activa, no escribe nada: entra. Si tiene que escribir su contraseña, el campo le confirma que debe usar su cédula — no adivina. Si algo falla, no se queda solo frente a un mensaje críptico: le dicen qué pasó y qué hacer.

**Lo que entiende cuando llega al home:**
Que todo su dinero está en un solo lugar. Ve el total antes de ver el detalle. Sabe si su principal inversión subió o bajó este mes sin tener que navegar. Encuentra en menos de dos toques lo que vino a hacer — aporte, retiro, movimientos.

**Con qué motivación sale después de una sesión exitosa:**
Con la sensación de que tiene control. No necesitó ayuda para entrar. Encontró lo que buscaba. Entiende, aunque sea de forma básica, cómo está yendo su dinero. Skandia no le habló en difícil. Si hay algo relevante para su perfil, lo vio sin sentirse presionado a actuar. El tiempo que invirtió — 86 segundos en promedio — valió la pena.

**El arco completo:**
Login (claridad funcional, cero fricción) → Home (contexto financiero inmediato) → Acción (un toque, sin scroll) → Salida con sensación de control. Este arco solo funciona si el tono es consistente en cada punto: no hay pantallas "más formales" ni momentos "más casuales". La voz de Skandia en la app es una sola.

---

## Decisiones de contenido pendientes

- 🟡 **Biometría — disclaimers legales:** Cualquier copy que asocie autenticación biométrica con "seguridad garantizada" debe pasar por Legal antes de producción.
- 🟡 **Rentabilidades — validar período y cálculo:** El microcopy "Rentabilidad del mes / Respecto al mes anterior" debe confirmarse con el equipo de datos. Si el período de cálculo varía por tipo de producto, el copy debe adaptarse por tarjeta.
- 🟡 **Banners — disclaimer regulatorio de inversión:** El texto propuesto ("no es una recomendación de inversión") debe ser revisado y aprobado por Legal/Compliance antes de producción.
- 🟡 **Campo usuario (cédula):** Confirmar con el equipo técnico que el placeholder "Ej. 1023456789" no genera conflicto con validaciones del campo (espacios, puntos, longitud).
- 🟡 **Estado vacío con CTA comercial:** Validar con Negocio qué productos se pueden mostrar en el CTA del estado vacío y para qué segmentos — especialmente en categorías Seguros y Crédito.
- 🟡 **Canal de soporte:** El enlace "¿Necesitas ayuda?" en errores de login requiere definir el canal de destino (chat, call center, FAQ). Pendiente confirmar con el equipo.
- 🟡 **Modo de privacidad / ocultar saldo:** Validar con el equipo técnico si el toggle persiste entre sesiones o se resetea al cerrar la app — el copy puede necesitar ajuste si hay diferencias entre iOS y Android.
- 🟡 **Segmento Finanzas Personales — educación financiera:** El research identifica que para este segmento (50 % de usuarios de App) la prioridad es educación financiera, no promoción de productos. Esta fase no cubre contenido educativo, pero debe quedar documentado como insumo para fases posteriores.
- 🟡 **Session timeout — revisión legal del copy:** El texto "Cerramos tu sesión para proteger tu cuenta" implica una acción activa de Skandia sobre la sesión del usuario. Validar con Legal si esta formulación es admisible o si requiere una versión más neutral ("Tu sesión se cerró automáticamente por inactividad").
- 🟡 **Estado de transacción "No procesada" — alineación con producto:** Confirmar con el equipo de producto el término exacto que el sistema usa para transacciones fallidas o rechazadas. El copy de la Pantalla 11 debe reflejar el término del sistema, no un término arbitrario de content.
- 🟡 **Countdown de OTP — duración real:** El microcopy "Podés pedir otro código en [X] segundos" requiere que el equipo técnico confirme el tiempo de bloqueo real del sistema antes de producción. El valor de [X] no puede ser una estimación en el copy final.
