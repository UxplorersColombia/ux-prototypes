# PRD — Login_Dash_App
**Fecha:** 2026-06-12
**Estratega:** Harvey · UX Estratega · Skandia UX Team
**Para:** Rachel (ux-ui-designer)
**Insumos:** Login_Dash_App-research.md ✅ · Login_Dash_App-content.md ✅

---

## 1. Contexto

- **Caso:** Rediseño de Login (usuario existente) + Home del ecosistema — app móvil Skandia Colombia
- **Canal:** App móvil iOS y Android · mobile-first · viewport base 375px
- **Segmento principal:** Clientes existentes con productos activos — perfil predominante 30–39 años (mayor volumen absoluto: 14.381 usuarios). Segmentos presentes: Finanzas Personales (50 % de usuarios de App), Joven Pro (mayor tasa de adopción, 29,2 %), Privilegio, Elite y Elite Wealth (menor volumen, mayor saldo, edad promedio 50–62 años).
- **Outcome de negocio:** Que el cliente sienta que Skandia es un solo producto coherente, independientemente del dispositivo o canal desde el que acceda. La brecha visual y de experiencia entre la app móvil y el portal web erosiona la coherencia de marca y, con ella, la confianza del usuario en el ecosistema.
- **Problema del usuario:** La app y el portal se perciben como productos distintos. El flujo de acceso presenta fricciones de autenticación documentadas (campo de usuario ambiguo, errores de biometría, mensajes de error crípticos). El home no comunica la posición financiera total del usuario ni facilita la primera acción post-login — solo muestra capital, no rentabilidad, y coloca banners comerciales antes de la información del propio usuario.
- **Cómo medir el éxito:**
  - Reducción de la tasa de abandono en el flujo de login
  - Aumento de la adopción de biometría (huella / Face ID)
  - Reducción del tiempo hasta la primera acción en el home
  - Mejora en la percepción de coherencia de marca (NPS por canal / encuesta post-lanzamiento)
- **Promesa central de contenido (Kiki):** "Tu dinero está aquí, claro y disponible — en los mismos segundos que tienes para revisarlo."

---

## 2. Clasificación de riesgo

| Dimensión | Nivel | Razón |
|---|---|---|
| Regulatorio | Medio | CTAs de login con biometría requieren disclaimers validados por Legal. Banner contextual de cross-sell tiene disclaimer de inversión pendiente de aprobación Legal/Compliance. Visualización de rentabilidades requiere confirmación del período de cálculo con el equipo de datos. Session timeout copy pendiente de revisión legal. |
| Usabilidad | Alto | El segmento mayoritario (Finanzas Personales, 50 % de App) incluye usuarios con baja alfabetización financiera. El flujo de login tiene 5 estados de error documentados. El home debe resolver la necesidad del usuario en menos de 86 segundos (mediana de sesión). El 80,1 % de los detractores califica la experiencia como difícil o neutra — la percepción de dificultad es el driver principal de detracción. |
| Técnico | Medio | El flujo de recuperación de acceso requiere integración con el sistema de OTP (tiempo real del countdown pendiente de confirmación técnica). La biometría falla en el 23 % de intentos según el deep dive de retiros (Databricks) — el motor biométrico puede afectar el login. Los flujos operativos (aportes, retiros) no se modifican en esta fase — solo el acceso a ellos. |
| Negocio | Alto | Afecta directamente la tasa de adopción de la App (actualmente 9,5 % de la base total). La coherencia visual con el portal es un driver de adopción medible (44,5 % de adopción entre usuarios activos del portal vs. 0,01 % entre quienes nunca lo usaron). Los detractores duplican a los del portal (16,7 % vs. 7,6 %). Un rediseño exitoso impacta directamente el NPS, la retención y el acceso a flujos de ingreso. |

**Nivel compuesto: Medio**
_(Usabilidad y Negocio en Alto; Regulatorio y Técnico en Medio. 2 dimensiones en Alto = Riesgo Medio con decisiones críticas marcadas. Validaciones necesarias antes de producción.)_

---

## 3. Estructura del flujo

**Tipo:** B — Brief con jerarquía de contenido

**Razón:** El flujo cubre 11 pantallas distribuidas en dos macrobloques (Login + Home) sin un arco emocional continuo entre ambos. El login es un flujo funcional de acceso — el usuario llega con intención clara: entrar. El home es un flujo de navegación de información multistep donde el usuario consulta, no es convencido. No hay un estado mental A → B que justifique narrativa formal. Sin embargo, dentro del bloque Home existe una secuencia de jerarquía de información que debe preservarse: primero el contexto financiero propio (saldo, productos, rentabilidad), luego las acciones, luego el contexto comercial (banners).

**Macrobloques:**

- **Bloque I — Login (Pantallas 1–4):** Flujo transaccional de acceso. Ruta principal (biometría) + fallback (contraseña) + estados de error + recuperación de acceso. Jerarquía clara: biometría > contraseña > recuperación.
- **Bloque II — Home (Pantallas 5–11):** Flujo de consulta y primera acción. Jerarquía: saldo consolidado → producto principal → acciones rápidas → productos adicionales → movimientos recientes → banner contextual → estado vacío.

---

## 4. Arquitectura de información

---

### Pantalla 1 — Login con biometría (ruta principal)

- **Bloque:** I — Login
- **Job:** El usuario entra a la app en el menor número de pasos posibles usando su huella o reconocimiento facial. La biometría es la ruta por defecto, no una opción secundaria.
- **Jerarquía de contenido:**
  1. Logotipo Skandia (marca y contexto de dónde está el usuario)
  2. Título de bienvenida
  3. Ícono biométrico centrado (huella / Face ID — se activa automáticamente al abrir la app)
  4. Subtítulo que indica el método de ingreso
  5. CTA principal biométrico (adaptado al dispositivo)
  6. Enlace secundario para acceso con contraseña (visible pero subordinado)
- **Componentes sk-*:**
  - `sk-button` (variante primary) → CTA principal biométrico
  - `sk-button` (variante tertiary o link) → "¿Prefieres usar tu contraseña?"
- **Microcopy clave** _(de Login_Dash_App-content.md)_:
  - Título: "Hola de nuevo"
  - Subtítulo: "Usa tu huella o tu rostro para ingresar" / En iOS: "Face ID o huella digital"
  - CTA principal: "Ingresar con huella digital" / "Ingresar con Face ID" (según dispositivo)
  - Enlace secundario: "¿Prefieres usar tu contraseña?"
  - Error/validación: "No reconocemos tu huella. Intenta de nuevo o ingresa con tu contraseña."
- **Restricciones:**
  - Cualquier mensaje relacionado con autenticación biométrica que implique promesas de seguridad debe pasar por revisión legal antes de producción.
  - El ícono debe activar el lector biométrico automáticamente al abrir la app — confirmación técnica requerida.
  - Adaptar CTA al tipo de biometría del dispositivo (iOS Face ID / huella Android) — requiere lógica de detección de capacidades.
- **Transición:** Viene de la apertura de la app (splash / onboarding) · Va hacia Home (Pantalla 5) si la autenticación es exitosa, o hacia Pantalla 3 (error) si falla

---

### Pantalla 2 — Login con contraseña (fallback)

- **Bloque:** I — Login
- **Job:** Dar acceso seguro cuando la biometría no está disponible, falla, o el usuario la rechaza. Eliminar la ambigüedad del campo de usuario — este es el punto de mayor fricción documentado en verbatims.
- **Jerarquía de contenido:**
  1. Logotipo Skandia
  2. Título de pantalla
  3. Campo 1: número de cédula (label explícito + placeholder con formato real)
  4. Campo 2: contraseña (label + toggle de visibilidad con texto + ícono)
  5. Enlace "¿Olvidaste tu contraseña?" (justo debajo del campo de contraseña — donde el usuario lo busca)
  6. CTA principal de ingreso
  7. Aviso de activación biométrica (solo si el usuario no tiene biometría configurada)
- **Componentes sk-*:**
  - `sk-input` (tipo text) → campo número de cédula, con label "Número de cédula" y placeholder "Ej. 1023456789"
  - `sk-input` (tipo password) → campo contraseña, con toggle de visibilidad texto + ícono
  - `sk-button` (variante primary) → CTA "Ingresar"
  - `sk-button` (variante link o tertiary) → "¿Olvidaste tu contraseña?"
  - `sk-messages` o `sk-toast` → estado de error inline (si aplica)
- **Microcopy clave** _(de Login_Dash_App-content.md)_:
  - Título: "Ingresa a tu cuenta"
  - Subtítulo: — (no necesario; los campos y labels son suficientes)
  - Label campo 1: "Número de cédula"
  - Placeholder campo 1: "Ej. 1023456789"
  - Label campo 2: "Contraseña"
  - Toggle visibilidad: "Mostrar contraseña" + ícono de ojo
  - CTA principal: "Ingresar"
  - Enlace recuperación: "¿Olvidaste tu contraseña?"
  - Aviso biometría (condicional): "¿Tienes huella o Face ID? Actívalo aquí"
  - Error/validación: "No reconocemos esta contraseña. Verifica que el bloqueo de mayúsculas esté desactivado e inténtalo de nuevo."
- **Restricciones:**
  - No usar placeholder en el campo de contraseña — estándar de accesibilidad.
  - El aviso de activación biométrica solo se muestra si el usuario no tiene biometría configurada — requiere flag de estado del dispositivo/cuenta.
  - Confirmar con el equipo técnico que el placeholder "Ej. 1023456789" no genera conflicto con validaciones del campo (espacios, puntos, longitud).
  - El toggle "Mostrar contraseña" debe incluir texto + ícono — no solo el ícono — para accesibilidad de segmentos 50+ (Elite, Elite Wealth, edad promedio 54–62 años).
- **Transición:** Viene de Pantalla 1 (enlace "¿Prefieres usar tu contraseña?") o de Pantalla 3 (Error E — biometría bloqueada) · Va hacia Home (Pantalla 5) si el acceso es exitoso, o hacia Pantalla 3 (error) si falla

---

### Pantalla 3 — Estados de error de autenticación

- **Bloque:** I — Login
- **Job:** Informar al usuario exactamente qué pasó y qué debe hacer — sin generar ansiedad adicional. Este es el momento de mayor riesgo de abandono. El copy debe ser el más claro de toda la app.
- **Jerarquía de contenido (por estado):**
  1. Ícono de estado (no de error crítico — tono empático)
  2. Título del error (qué pasó — una frase, sin culpar al usuario)
  3. Descripción breve (causa más frecuente + instrucción concreta)
  4. CTA principal (acción de salida del error)
  5. CTA secundario o enlace (alternativa)
- **Componentes sk-*:**
  - `sk-messages` o `sk-alert` → contenedor del mensaje de error con ícono, título y descripción
  - `sk-button` (variante primary) → CTA principal por estado
  - `sk-button` (variante secondary o link) → CTA secundario o enlace de soporte
  - `sk-dialog` o pantalla completa → según el tipo de error (errores de bloqueo de cuenta pueden requerir pantalla full)
- **Microcopy clave** _(de Login_Dash_App-content.md — todos los estados)_:

  **Error A — Contraseña incorrecta (1.er intento)**
  - Título: "No reconocemos esta contraseña"
  - Descripción: "Verifica que el bloqueo de mayúsculas esté desactivado e inténtalo de nuevo."
  - CTA: "Intentar de nuevo"
  - Enlace secundario: "¿Olvidaste tu contraseña?"

  **Error B — Contraseña incorrecta (3.er intento / bloqueo inminente)**
  - Título: "Un intento más y tu cuenta se bloqueará"
  - Descripción: "Si olvidaste tu contraseña, puedes recuperarla ahora y evitar el bloqueo."
  - CTA principal: "Recuperar mi contraseña"
  - CTA secundario: "Intentar de nuevo"

  **Error C — Cuenta bloqueada**
  - Título: "Tu cuenta está bloqueada temporalmente"
  - Descripción: "Esto ocurre después de varios intentos fallidos. Puedes desbloquearla en menos de dos minutos."
  - CTA principal: "Desbloquear mi cuenta"

  **Error D — Error técnico / app no responde**
  - Título: "Algo falló de nuestro lado"
  - Descripción: "Estamos trabajando para resolverlo. Espera unos minutos e inténtalo de nuevo."
  - CTA: "Intentar de nuevo"
  - Microcopy: "Si el problema persiste, contáctanos." (enlace a soporte)

  **Error E — Biometría bloqueada**
  - Título: "Tu huella digital está bloqueada"
  - Descripción: "Esto puede ocurrir después de varios intentos fallidos. Ingresa con tu contraseña para desbloquearla."
  - CTA principal: "Ingresar con contraseña"
  - Microcopy: "¿Necesitas ayuda?" (enlace a soporte)

  **Error F — Sesión cerrada por inactividad**
  - Título: "Cerramos tu sesión para proteger tu cuenta"
  - Descripción: "Detectamos que tu sesión estuvo inactiva por un tiempo. Es una medida de seguridad automática."
  - CTA principal: "Ingresar con huella digital" / "Ingresar con Face ID"
  - CTA secundario: "Ingresar con contraseña"

- **Restricciones:**
  - El enlace de soporte en Error D y Error E requiere definir el canal de destino (chat, call center, FAQ) — pendiente confirmar con el equipo.
  - El copy de Error F ("Cerramos tu sesión para proteger tu cuenta") implica una acción activa de Skandia. Validar con Legal si esta formulación es admisible o si requiere versión más neutral ("Tu sesión se cerró automáticamente por inactividad").
  - El copy de Error E requiere validación legal si asocia autenticación biométrica con garantías de seguridad.
  - El contador de intentos (Error A → B → C) requiere lógica del sistema — confirmar cuántos intentos activan cada estado.
- **Transición:** Llega desde Pantalla 1 (error biometría) o Pantalla 2 (error contraseña) · Desde Error E va hacia Pantalla 2 · Desde Error F va hacia Pantalla 1 o 2 · Desde Errores B/C va hacia Pantalla 4 (recuperación)

---

### Pantalla 4 — Recuperación de acceso

- **Bloque:** I — Login
- **Job:** Que el usuario recupere el acceso en el menor número de pasos. El copy transmite que el proceso es corto y controlado — no un trámite. Incluye un bottom sheet previo que gestiona las expectativas antes de iniciar el flujo.
- **Jerarquía de contenido:**

  **Sub-pantalla 4a — Bottom sheet de advertencia (antes de iniciar)**
  1. Título del bottom sheet
  2. Lista de requisitos (cédula + acceso al correo/celular registrado)
  3. Advertencia de cambio de contexto
  4. CTA principal (continuar)
  5. CTA secundario (cancelar — sin consecuencias)

  **Sub-pantalla 4b — Flujo principal de recuperación**
  1. Título orientado al resultado
  2. Subtítulo que explica qué va a pasar antes de que pase
  3. Campo de número de cédula
  4. CTA de envío de código
  5. Confirmación de envío con expectativa concreta de tiempo
  6. Campo de ingreso del código OTP
  7. CTA de reenvío en dos estados: inactivo con countdown / activo
  8. Hint de correo no deseado
  9. Microcopy de soporte para código no recibido
  10. Confirmación de éxito + CTA post-éxito

- **Componentes sk-*:**
  - `sk-dialog` o bottom sheet nativo → Sub-pantalla 4a (advertencia previa)
  - `sk-button` (variante primary) → "Continuar con la recuperación"
  - `sk-button` (variante secondary) → "Cancelar"
  - `sk-input` (tipo text) → campo número de cédula
  - `sk-inputmask` → campo código OTP (si requiere máscara de formato)
  - `sk-button` (variante primary) → "Enviar código de verificación"
  - `sk-button` (variante secondary, estado deshabilitado con contador) → CTA de reenvío inactivo
  - `sk-button` (variante secondary, habilitado) → "Pedir otro código"
  - `sk-toast` o `sk-messages` → confirmación de envío, errores de código
  - `sk-progressspinner` → estado de carga durante envío
- **Microcopy clave** _(de Login_Dash_App-content.md)_:

  **Bottom sheet 4a:**
  - Título: "Para recuperar tu acceso, necesitarás:"
  - Cuerpo: "· Tu número de cédula\n· Acceso al correo o celular registrado en tu cuenta"
  - Advertencia: "Saldrás del flujo actual y comenzarás el proceso de recuperación."
  - CTA principal: "Continuar con la recuperación"
  - CTA secundario: "Cancelar"

  **Flujo principal 4b:**
  - Título: "Recupera el acceso a tu cuenta"
  - Subtítulo: "Te enviamos un código a tu correo o celular registrado para verificar tu identidad."
  - Label campo: "Número de cédula"
  - CTA principal: "Enviar código de verificación"
  - Confirmación de envío: "Revisá tu correo o tu celular. El código llega en menos de un minuto."
  - Error código incorrecto: "Este código no es válido. Verifica que lo hayas copiado correctamente o solicita uno nuevo."
  - Error código expirado: "Este código ya expiró. Solicita uno nuevo para continuar."
  - CTA reenvío (inactivo): "Podés pedir otro código en [X] segundos"
  - CTA reenvío (activo): "Pedir otro código"
  - Hint: "(Revisá también tu carpeta de correo no deseado)"
  - Microcopy soporte: "¿No recibes el código? Verifica que el correo y el celular registrados sean los correctos."
  - Éxito: "Listo. Tu nueva contraseña está activa. Puedes ingresar ahora."
  - CTA post-éxito: "Ingresar a mi cuenta"

- **Restricciones:**
  - El tiempo real del countdown de OTP ([X] segundos) debe confirmarse con el equipo técnico antes de producción. El valor de [X] no puede ser una estimación en el copy final.
  - Validar flujo de actualización de datos de contacto — el microcopy de soporte asume que el usuario puede verificar su correo/celular registrado desde otro canal.
  - El flujo de recuperación debe mantenerse completamente dentro de la app nativa — no redirigir a webview externo.
- **Transición:** Llega desde Pantalla 3 (Errores B/C/D) o desde el enlace "¿Olvidaste tu contraseña?" de Pantalla 2 · Va hacia Pantalla 1 o 2 post-éxito

---

### Pantalla 5 — Home: saludo y saldo consolidado

- **Bloque:** II — Home
- **Job:** Dar al usuario su posición financiera completa en los primeros segundos. La mediana de sesión es 86 segundos — el home debe entregar valor en los primeros 10. Esta es la pantalla más importante del flujo post-login.
- **Jerarquía de contenido (primera pantalla, sin scroll — cubre al 77,8 % de usuarios):**
  1. Saludo personalizado con nombre de pila
  2. Saldo total consolidado (número prominente)
  3. Toggle ocultar/mostrar saldo (texto + ícono, junto al número)
  4. Label del saldo y subtexto explicativo
  5. Microcopy de fecha y hora de actualización
  6. Producto principal (mayor saldo o más penetrado — Fondos Mutuos 69,2 %)
  7. Acciones rápidas (máximo 4, alcanzables con el pulgar)
- **Componentes sk-*:**
  - `sk-card` → contenedor del saldo consolidado
  - `sk-button` (variante icon o toggle) → toggle ocultar/mostrar saldo con texto + ícono (ojo abierto/cerrado)
  - `sk-badge` o `sk-tag` → microcopy de fecha de actualización
  - `sk-skeleton` → estado de carga mientras se obtiene el saldo
  - `sk-messages` o `sk-alert` → error de saldo no disponible
  - `sk-button` (variante primary, tamaño small) → "Recargar" en estado de error
- **Microcopy clave** _(de Login_Dash_App-content.md)_:
  - Saludo: "Hola, [Nombre]"
  - Saldo total: "$[monto] COP"
  - Label saldo: "Tu saldo total"
  - Toggle: "Ocultar saldo" / "Mostrar saldo"
  - Subtexto saldo: "Suma de todos tus productos activos"
  - Microcopy fecha: "Actualizado hoy a las [HH:MM]"
  - Error saldo no disponible: "No pudimos cargar tu saldo ahora mismo. Intenta recargar."
  - CTA error: "Recargar"
- **Restricciones:**
  - Validar con el equipo técnico si el toggle ocultar/mostrar saldo persiste entre sesiones o se resetea al cerrar la app — el copy puede necesitar ajuste si hay diferencias entre iOS y Android.
  - El formato de moneda "$[monto] COP" debe ser consistente con el portal web.
  - Preservar los nombres personalizados de fondos (hallazgo nuevo del research — "Casita", "Mi retiro feliz", etc.) — este feature tiene alto valor emocional y solo es visible actualmente en la vista de Productos, no en el Home. El rediseño debe potenciar su visibilidad.
- **Transición:** Llega desde Pantalla 1 o 2 (autenticación exitosa) · El scroll lleva hacia Pantallas 6/7 (tarjetas de producto)

---

### Pantalla 6 — Tarjeta de producto: 1 producto (caso principal — Fondos Mutuos, 69,2 % de usuarios)

- **Bloque:** II — Home
- **Job:** El usuario con un solo producto necesita más contexto en esa tarjeta. No solo "cuánto tienes" sino "cómo vas". Los verbatims lo piden explícitamente: "No es claro cómo cada portafolio está performando."
- **Jerarquía de contenido:**
  1. Label de categoría del producto
  2. Nombre del producto (nomenclatura oficial del portal — no renombrar)
  3. Nombre personalizado del fondo (si existe — feature de alto valor emocional, ej. "Casita")
  4. Saldo del producto
  5. Label de rentabilidad + valor con color (verde positivo / rojo negativo)
  6. Microcopy de contexto de la rentabilidad
  7. Tooltip de rentabilidad (accesible por toque sobre el valor o un ícono de info)
  8. CTA principal "Ver mi portafolio"
  9. CTA secundario "Hacer un aporte"
- **Componentes sk-*:**
  - `sk-card` → contenedor de la tarjeta de producto (variante grande para 1 solo producto)
  - `sk-badge` → label de categoría ("Inversión")
  - `sk-metergroup` o gráfico nativo → espacio para gráfico de evolución (si la data está disponible)
  - `sk-chip` o `sk-tag` → valor de rentabilidad con color semántico del Design System
  - `sk-tooltip` → explicación del cálculo de rentabilidad al tocar el valor
  - `sk-button` (variante primary) → "Ver mi portafolio"
  - `sk-button` (variante secondary) → "Hacer un aporte"
- **Microcopy clave** _(de Login_Dash_App-content.md)_:
  - Label categoría: "Inversión"
  - Nombre del producto: "Fondos Mutuos"
  - Saldo del producto: "$[monto] COP"
  - Label rentabilidad: "Rentabilidad del mes"
  - Valor rentabilidad: "+[X,XX] %" o "−[X,XX] %" (color verde / rojo del Design System; sin texto adicional si el ícono es claro)
  - Microcopy rentabilidad: "Respecto al mes anterior"
  - CTA principal: "Ver mi portafolio"
  - CTA secundario: "Hacer un aporte"
  - Tooltip rentabilidad: "Este porcentaje refleja el rendimiento de tu fondo en el último mes calendario."
- **Restricciones:**
  - El microcopy "Rentabilidad del mes / Respecto al mes anterior" debe confirmarse con el equipo de datos antes de producción. Si el período de cálculo varía por tipo de producto, el copy debe adaptarse por tarjeta.
  - La nomenclatura oficial de categorías (Inversión · Pensión & Cesantías · Seguros · Crédito) no se modifica.
  - Los nombres personalizados de fondos (feature existente en v7.1.5) deben preservarse y potenciarse en esta tarjeta.
- **Transición:** Visible en la primera pantalla (sin scroll) para usuarios con 1 producto · Toque en "Ver mi portafolio" navega al detalle del producto (flujo fuera del alcance de esta fase) · Toque en "Hacer un aporte" navega al flujo de aportes (no se rediseña en esta fase)

---

### Pantalla 7 — Tarjeta de producto: 2 productos apilados

- **Bloque:** II — Home
- **Job:** El 34,2 % de usuarios tiene exactamente 2 productos. Las tarjetas deben permitir comparar de un vistazo sin hacer scroll excesivo ni perder la jerarquía establecida en la Pantalla 5.
- **Jerarquía de contenido:**
  1. Tarjeta 1 — producto de mayor saldo o mayor penetración
     - Label categoría + nombre de producto en una línea
     - Saldo
     - Rentabilidad (solo el dato más reciente)
     - CTA "Ver detalle"
  2. Tarjeta 2 — segundo producto
     - Mismo formato que Tarjeta 1 (consistencia visual obligatoria)
     - CTA "Ver detalle"
  3. Estado de carga parcial (si un producto no carga — mensaje específico, no tarjeta en blanco)
- **Componentes sk-*:**
  - `sk-card` (variante mediana) → dos tarjetas apiladas verticalmente
  - `sk-badge` → label de categoría en cada tarjeta
  - `sk-chip` o `sk-tag` → valor de rentabilidad con color semántico
  - `sk-button` (variante secondary o link) → "Ver detalle" en cada tarjeta
  - `sk-skeleton` → estado de carga por tarjeta individual
  - `sk-messages` → estado de carga parcial si un producto no está disponible
- **Microcopy clave** _(de Login_Dash_App-content.md)_:
  - Label tarjeta 1: "Inversión · Fondos Mutuos"
  - Label tarjeta 2: "[Categoría] · [Nombre del producto]"
  - Saldo tarjeta 1: "$[monto] COP"
  - Saldo tarjeta 2: "$[monto] COP"
  - Rentabilidad tarjeta: "+[X,XX] %"
  - CTA por tarjeta: "Ver detalle"
  - Estado carga parcial: "Estamos cargando la información de este producto."
- **Restricciones:**
  - En el caso de 2 tarjetas, el saldo consolidado de Pantalla 5 ya hace el trabajo de resumen — no repetir el total en las tarjetas individuales.
  - El diseño de las tarjetas medianas (2 productos) debe diferenciarse visualmente de la tarjeta grande (1 producto) — la densidad de información varía.
  - El orden de las tarjetas debe seguir una lógica consistente (mayor saldo o mayor penetración primero) — confirmar criterio de ordenamiento con el equipo de producto.
- **Transición:** Visible después del scroll desde Pantalla 5 (cuando el usuario tiene 2 productos) · Lleva hacia el detalle de cada producto (flujo fuera del alcance de esta fase)

---

### Pantalla 8 — Acciones rápidas

- **Bloque:** II — Home
- **Job:** Las 4 acciones más frecuentes deben estar a un toque desde el home — sin scroll, alcanzables con el pulgar. Los CTAs comunican acción + contenido, no solo el nombre del flujo.
- **Jerarquía de contenido:**
  1. Label de sección "Acciones frecuentes"
  2. Grilla de 4 botones de acción (ícono + label)
     - Aportar
     - Retirar
     - Mis movimientos
     - Mis documentos
  3. Estado deshabilitado (si un flujo está en mantenimiento)
- **Componentes sk-*:**
  - `sk-button` (variante icon + label, tamaño large o grid) → los 4 botones de acción rápida
  - `sk-tag` o `sk-chip` → label de sección "Acciones frecuentes"
  - `sk-tooltip` o `sk-badge` → indicador de estado deshabilitado ("No disponible ahora") con ícono en gris
- **Microcopy clave** _(de Login_Dash_App-content.md)_:
  - Label sección: "Acciones frecuentes"
  - Acción 1: "Aportar" + ícono de suma
  - Acción 2: "Retirar" + ícono de retiro
  - Acción 3: "Mis movimientos"
  - Acción 4: "Mis documentos"
  - Estado deshabilitado: Ícono en gris + "No disponible ahora"
- **Restricciones:**
  - Las 4 acciones deben ser alcanzables con el pulgar en la primera pantalla (sin scroll) — posición en la jerarquía del home es crítica.
  - El texto en acciones rápidas debe ser mínimo. El ícono y el label hacen el trabajo conjunto.
  - Las acciones rápidas acceden a flujos existentes que no se rediseñan en esta fase — confirmar que los deep links o navegación al interior de cada flujo están definidos.
- **Transición:** Visible en la primera pantalla del home (sin scroll) · Cada acción navega a su flujo respectivo (flujos fuera del alcance de rediseño en esta fase)

---

### Pantalla 9 — Banner contextual

_(Solo para usuarios con oportunidad de cross-sell identificada — Joven Pro o superior)_

- **Bloque:** II — Home
- **Job:** Comunicar una oportunidad relevante sin interrumpir el flujo principal. El banner aparece siempre después de los productos existentes. Para Finanzas Personales con 1 solo producto: no mostrar.
- **Jerarquía de contenido:**
  1. Etiqueta de personalización "Para ti"
  2. Título del banner (específico al producto sugerido — no genérico)
  3. Descripción con beneficio concreto
  4. Disclaimer regulatorio de inversión
  5. CTA con nombre del producto
  6. Control de cierre accesible (ícono X + texto)
- **Componentes sk-*:**
  - `sk-card` (variante banner / destacada) → contenedor del banner
  - `sk-tag` o `sk-badge` → etiqueta "Para ti"
  - `sk-button` (variante primary) → CTA del banner
  - `sk-button` (variante icon, ícono X) → cierre del banner, con label accesible
- **Microcopy clave** _(de Login_Dash_App-content.md)_:
  - Etiqueta: "Para ti"
  - Título del banner: "Diversifica tu portafolio con Pensión Voluntaria"
  - Descripción: "Con tu perfil, podrías aumentar tu rentabilidad a largo plazo. Conoce cómo."
  - CTA: "Conocer Pensión Voluntaria"
  - Disclaimer: "Esto es una sugerencia basada en tu perfil — no es una recomendación de inversión."
  - Cierre: Ícono X visible + texto accesible "Cerrar sugerencia"
  - Estado sin oportunidad: No se muestra el banner. No sustituir con banner genérico de publicidad.
- **Restricciones:**
  - La descripción del banner ("podrías aumentar tu rentabilidad a largo plazo") y el disclaimer completo deben ser revisados y aprobados por Legal/Compliance antes de producción.
  - Las reglas de presentación son estrictas: solo usuarios con oportunidad de cross-sell identificada Y segmento Joven Pro o superior. Finanzas Personales con 1 solo producto: no mostrar. Posición: siempre después de productos existentes.
  - El título y CTA son ejemplos para el producto "Pensión Voluntaria" — el sistema debe ser capaz de adaptar el copy dinámicamente al producto sugerido para cada usuario.
- **Transición:** Visible después del primer scroll, posterior a las tarjetas de producto (Pantallas 6/7) y a los movimientos recientes (Pantalla 11) · El CTA navega al detalle del producto sugerido

---

### Pantalla 10 — Estado vacío o categoría sin producto activo

- **Bloque:** II — Home
- **Job:** El 43,6 % tiene 1 solo producto — verá categorías vacías. El estado vacío no debe generar confusión ni sensación de error. Tampoco debe ser una oportunidad de venta agresiva.
- **Jerarquía de contenido:**
  1. Ilustración neutra (sin colores de alerta, sin ícono de error)
  2. Título honesto y directo
  3. Descripción que explica la pantalla sin presionar al usuario
  4. CTA comercial (solo si el usuario tiene oportunidad de cross-sell identificada)
  5. Sin CTA (para Finanzas Personales sin oportunidad identificada)
- **Componentes sk-*:**
  - Ilustración SVG neutra del Design System → estado vacío
  - `sk-card` (variante vacía o estado nulo) → contenedor del estado
  - `sk-button` (variante secondary o link) → CTA "Conocer [nombre del producto]" (solo condicional)
- **Microcopy clave** _(de Login_Dash_App-content.md)_:
  - Título: "Todavía no tienes [nombre de categoría]" (ej.: "Todavía no tienes Seguros")
  - Descripción: "Cuando tengas un producto de esta categoría, podrás verlo aquí."
  - CTA (condicional): "Conocer [nombre del producto]"
  - Sin CTA (Finanzas Personales sin oportunidad): — (no mostrar CTA comercial)
- **Restricciones:**
  - El estado vacío con CTA comercial requiere validar con Negocio qué productos se pueden mostrar para cada categoría y para qué segmentos — especialmente Seguros y Crédito.
  - Los fondos con $0 sin comunicación de estado (hallazgo de la auditoría de la app v7.1.5) deben tratarse como un estado vacío con diseño específico — no dejar número de contrato visible sin contexto.
  - El estado vacío no necesita más texto que el propuesto — la simplicidad es la comunicación.
- **Transición:** Visible cuando el usuario navega a una categoría donde no tiene productos activos · El CTA condicional lleva al detalle del producto sugerido

---

### Pantalla 11 — Movimientos recientes (fragmento en el home)

- **Bloque:** II — Home
- **Job:** Confirmar al usuario el estado de sus transacciones más recientes sin que tenga que navegar. Responde directamente al verbatim: "No sé si quedó registrada mi solicitud de retiro."
- **Posición en el home:** Después de las tarjetas de producto (Pantallas 6/7) y antes del banner contextual (Pantalla 9).
- **Máximo a mostrar:** 2–3 transacciones. Si no hay movimientos recientes, no mostrar la sección.
- **Jerarquía de contenido:**
  1. Label de sección "Movimientos recientes"
  2. Lista de 2–3 ítems, cada uno con: tipo de operación + fecha + monto + etiqueta de estado
  3. Etiqueta de estado con color semántico (verde / amarillo / rojo del Design System)
  4. Enlace "Ver qué pasó" (solo para movimientos con estado "No procesada")
  5. CTA de sección "Ver todos mis movimientos"
  6. Omitir la sección completa si no hay movimientos en los últimos 30 días
- **Componentes sk-*:**
  - `sk-tag` o `sk-badge` → etiqueta de estado por ítem ("Procesada" en verde / "En proceso" en amarillo-neutro / "No procesada" en rojo)
  - `sk-card` o lista nativa → contenedor de la sección de movimientos
  - `sk-button` (variante link o tertiary) → "Ver qué pasó" (para estado No procesada)
  - `sk-button` (variante link o tertiary) → "Ver todos mis movimientos" (al final de la sección)
- **Microcopy clave** _(de Login_Dash_App-content.md)_:
  - Label sección: "Movimientos recientes"
  - Estructura por ítem: [Tipo de operación] · [Fecha] · [Monto] · [Estado]
  - Etiqueta estado "Procesada": "Procesada" (color verde del Design System)
  - Ejemplo ítem procesado: "Retiro · 10 jun · $500.000 COP · Procesada"
  - Etiqueta estado "En proceso": "En proceso" (color amarillo/neutro del Design System)
  - Ejemplo ítem en proceso: "Aporte · 11 jun · $200.000 COP · En proceso"
  - Etiqueta estado "No procesada": "No procesada" (confirmar término exacto con el equipo de producto)
  - Microcopy estado rechazado: "Ver qué pasó" (enlace al detalle del movimiento)
  - CTA sección: "Ver todos mis movimientos"
  - Estado vacío de sección: No mostrar la sección (sin estado vacío visible)
- **Restricciones:**
  - El término exacto para transacciones fallidas o rechazadas ("No procesada", "Rechazada", "Fallida") debe confirmarse con el equipo de producto antes de producción. El copy debe reflejar el término del sistema, no un término arbitrario.
  - La sección se omite completamente si no hay movimientos en los últimos 30 días — no mostrar un estado vacío.
  - La etiqueta de estado es el elemento más importante visualmente de cada ítem — debe tener mayor jerarquía que el tipo de operación o la fecha.
- **Transición:** Visible después del primer scroll, entre las tarjetas de producto y el banner contextual · "Ver todos mis movimientos" lleva al historial completo (consistente con la acción rápida "Mis movimientos" de Pantalla 8)

---

## 5. Principios de diseño para este caso

**1. La biometría no es opcional — es la entrada.**
La app v7.1.5 ya tiene la jerarquía correcta (biometría como CTA primario). El rediseño la refuerza: el ícono biométrico se activa automáticamente al abrir la app, el fallback a contraseña es visible pero subordinado. La decisión está respaldada por el benchmark (Trii la tiene como opt-in post-login — Skandia la diferencia al hacerla la ruta por defecto) y por los datos (23 % de fallo biométrico en retiros es una señal sistémica que debe resolverse en paralelo — no es razón para deprioritizar la biometría en el login).

**2. El home responde "cómo vas", no solo "cuánto tienes".**
El home actual muestra capital sin rentabilidad y coloca banners antes de los productos del usuario. El rediseño invierte esa jerarquía: saldo consolidado → producto con rentabilidad visible → acciones → contexto comercial. Esto responde directamente a los 32 verbatims sobre visibilidad de rentabilidades y a los hallazgos de pasivos: "No es claro cómo cada portafolio está performando." El home debe entregar este contexto en los primeros 10 segundos de la sesión de 86 segundos de mediana.

**3. Los errores son momentos de servicio, no de culpa.**
El 80,1 % de detractores califica la experiencia como difícil. Los momentos de error (login fallido, biometría bloqueada, timeout de sesión) son los de mayor riesgo de abandono. Cada mensaje de error en este PRD sigue el mismo principio: qué pasó (una frase, sin culpar) + qué hacer ahora (una acción concreta). El copy de Nubank ("Cerramos tu sesión para proteger tu cuenta") es el modelo de tono. Los tecnicismos, la vaguedad y las disculpas vacías están fuera.

**4. La coherencia con el portal no es estética — es adopción.**
El 44,5 % de adopción entre usuarios activos del portal vs. el 0,01 % entre quienes nunca lo usaron confirma que la familiaridad visual impulsa la adopción multicanal. Los tokens de color, tipografía, nomenclatura de productos y tono de voz deben ser idénticos entre app y portal. La inconsistencia de registro tú/usted documentada en v7.1.5 (app habla de tú en el home, de usted en los dialogs) se corrige en su totalidad — sin excepciones, incluyendo dialogs y mensajes del sistema.

---

## 6. Decisiones pendientes antes de producción

- **Biometría — disclaimers legales:** Cualquier copy que asocie autenticación biométrica con "seguridad garantizada" debe pasar por Legal antes de producción. Afecta Pantallas 1 y 3 (Error E).
- **Rentabilidades — validar período y cálculo:** El microcopy "Rentabilidad del mes / Respecto al mes anterior" debe confirmarse con el equipo de datos. Si el período de cálculo varía por tipo de producto, el copy debe adaptarse por tarjeta. Afecta Pantallas 6 y 7.
- **Banners — disclaimer regulatorio de inversión:** El texto "no es una recomendación de inversión" debe ser revisado y aprobado por Legal/Compliance antes de producción. Afecta Pantalla 9.
- **Campo usuario (cédula):** Confirmar con el equipo técnico que el placeholder "Ej. 1023456789" no genera conflicto con validaciones del campo (espacios, puntos, longitud). Afecta Pantalla 2.
- **Estado vacío con CTA comercial:** Validar con Negocio qué productos se pueden mostrar en el CTA del estado vacío y para qué segmentos — especialmente en categorías Seguros y Crédito. Afecta Pantalla 10.
- **Canal de soporte:** El enlace "¿Necesitas ayuda?" en errores de login requiere definir el canal de destino (chat, call center, FAQ). Pendiente confirmar con el equipo. Afecta Pantalla 3 (Errores D y E).
- **Toggle ocultar saldo — persistencia entre sesiones:** Validar con el equipo técnico si el toggle persiste entre sesiones o se resetea al cerrar la app — el copy puede necesitar ajuste si hay diferencias entre iOS y Android. Afecta Pantalla 5.
- **Session timeout — revisión legal del copy:** El texto "Cerramos tu sesión para proteger tu cuenta" implica una acción activa de Skandia sobre la sesión del usuario. Validar con Legal si esta formulación es admisible o si requiere una versión más neutral ("Tu sesión se cerró automáticamente por inactividad"). Afecta Pantalla 3 (Error F).
- **Estado de transacción "No procesada" — alineación con producto:** Confirmar con el equipo de producto el término exacto que el sistema usa para transacciones fallidas o rechazadas. El copy de Pantalla 11 debe reflejar el término del sistema. Afecta Pantalla 11.
- **Countdown de OTP — duración real:** El microcopy "Podés pedir otro código en [X] segundos" requiere que el equipo técnico confirme el tiempo de bloqueo real del sistema antes de producción. Afecta Pantalla 4.
- **Biometría — tasa de fallo sistémico:** El 23 % de fallo biométrico documentado en el deep dive de retiros (Databricks) puede indicar un problema del motor biométrico que afecte también al login. Este no es un problema de diseño — debe escalarse al equipo técnico en paralelo al rediseño.
- **Firebase / analytics:** Las hipótesis H1, H2 y H3 del research (errores de autenticación, adopción biométrica) siguen abiertas sin fuente confirmada. Confirmar acceso a Firebase con el equipo técnico para medir el impacto del rediseño post-lanzamiento.

---

## 7. Instrucción a Rachel

- **Entregable esperado:** prototipo `.html` autocontenido
- **Figma:** solo si el equipo lo solicita explícitamente
- **Fuente de verdad de microcopy:** `Login_Dash_App-content.md` — todos los textos de interfaz deben tomarse literalmente de ese archivo. No parafrasear, no simplificar.
- **Canal principal:** App móvil iOS y Android — mobile-first, viewport base 375px. Densidad de contenido ajustada a sesiones de 86 segundos de mediana.
- **Segmento de diseño:** Optimizar el caso base para el perfil 30–39 años (mayor volumen, Joven Pro / Privilegio). Garantizar accesibilidad para segmentos 50+ (Elite, Elite Wealth) — tamaño de fuente, contraste, toggle con texto + ícono, no solo ícono.
- **Nomenclatura de productos:** Usar sin excepción la nomenclatura oficial: Inversión · Fondos Mutuos · Pensión & Cesantías · Pensión Obligatoria · Cesantías · Seguros · Crédito. No renombrar, no reorganizar.
- **Tokens del Design System:** Respetar los tokens de Skandia — colores (verde positivo / rojo negativo para rentabilidades), tipografía, espaciado. Los componentes sk-* definidos en la sección 4 son la referencia técnica.
- **Inconsistencia tú/usted:** Unificar en "tú" sin excepción en toda la app — incluyendo dialogs ("¿Deseas cerrar sesión?") y mensajes del sistema ("Apreciado cliente" → no usar).
- **Feature a preservar:** Los nombres personalizados de fondos (ej. "Casita", "Mi retiro feliz") son un feature de alto valor emocional existente en v7.1.5. El rediseño debe potenciar su visibilidad en el home, no ocultarla.
- **IP del último acceso:** La IP raw visible en el menú de la app actual (ej. "152.200.172.203") no tiene valor para el usuario promedio. Rediseñar como "Desde tu red habitual" o equivalente — o consultar con el equipo de producto si este dato debe permanecer.
- **Restricciones marcadas:** Los elementos con restricción activa en la sección 4 están pendientes de validación. Rachel puede diseñar el placeholder de ese elemento, pero el copy y la lógica final quedan bloqueados hasta resolución. Ver sección 6.

---

## 8. Señal de handoff a Kiki (Modo Revisora)

Una vez que Rachel entregue el prototipo `.html`, Kiki recibe para revisión de microcopy con los siguientes parámetros:

- **Canal:** App móvil iOS y Android
- **Segmento:** Clientes existentes con productos activos — perfil predominante 30–39 años. Segmentos activos: Finanzas Personales, Joven Pro, Privilegio, Elite, Elite Wealth.
- **Fuentes de verdad:**
  - `Login_Dash_App-content.md` — fuente primaria de microcopy aprobado
  - Design System Skandia (tokens de voz y tono)
  - Vocabulario aprobado y lista de palabras que no usamos (sección "Vocabulario" de `Login_Dash_App-content.md`)
- **Checklist de revisión prioritario:**
  1. Coherencia de registro (tú — sin excepción, incluidos dialogs y mensajes del sistema)
  2. Nomenclatura oficial de productos (Fondos Mutuos, Pensión & Cesantías, etc. — sin renombrar)
  3. Labels de campos (especialmente "Número de cédula" — no "Usuario", no "Correo")
  4. Copy de estados de error (principio: qué pasó + qué hacer; sin culpar al usuario)
  5. Disclaimers de rentabilidad y banners (verificar que coincidan con los aprobados por Legal)
  6. CTAs: ningún "Continuar" solo — todos los CTAs deben incluir contexto de acción o destino
  7. Copy del toggle ocultar/mostrar saldo ("Ocultar saldo" / "Mostrar saldo" — no solo el ícono)
- **Elementos marcados para revisión especial:** todos los ítems con restricción activa en la sección 6 de este PRD — en particular el copy de session timeout (Error F), el disclaimer del banner (Pantalla 9) y el estado de transacción "No procesada" (Pantalla 11).

---

*UX Estratega · Skandia Colombia · #UXplorers*
*Generado: 2026-06-12 · PRD versión 1.0 · Listo para revisión humana*
