# V3_Login_DashApp — notas de proyecto

## Estilo de cards (obligatorio)
Todas las cards/contenedores usan el estilo del componente "Categorías de productos":
- `background:#fff`
- `border:none`
- `box-shadow:0 0 4px 0 rgba(61,75,92,.15)`
- `border-radius:16px`

No usar bordes de color ni acentos laterales (border-left). Los estados (completada/en progreso/bloqueada) se comunican con el ícono, chips y color de texto, no con el borde de la card.

## Design system
Skandia — verde `#00c73d`, gradiente `linear-gradient(135deg,#00c73d,#8fe000)`, Montserrat (títulos) + Open Sans (cuerpo). Nunca ALL CAPS. Español informal (tú).
