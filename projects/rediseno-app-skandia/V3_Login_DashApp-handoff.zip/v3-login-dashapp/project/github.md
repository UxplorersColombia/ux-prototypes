repo: UxplorersColombia/ux-prototypes
branch: main
path: projects/rediseno-app-skandia

## Last sync
date: 2026-08-05T15:48:38Z

### Updated in this project
- Explorer nuevo: acción rápida "Primer aporte" sin interacción; "Asesórate" abre el panel de Asesoría.
- Checklist de bienvenida: añadidos "Activar biometría" (chequeado) y "Culminaste el paso 1 de tu ruta · Detox financiero"; progreso 4 de 5.
- Login: "Quiero ser cliente" como enlace secundario en cliente actual; alerta de ingreso rápido deshabilitado en usuario nuevo.
- Nuevo modal de Reglamento de uso de Canales Digitales tras ingresar con contraseña (cliente actual), con chip de scroll y aceptación.

## Screen map
| Pantalla | Archivos del repo |
|---|---|
| Login (cliente actual / usuario nuevo / Explorer) | projects/rediseno-app-skandia/v1/index.html |
| Crear cuenta (3 pasos) | projects/rediseno-app-skandia/v1/index.html |
| Home / Dashboard Explorer | projects/rediseno-app-skandia/v1/index.html |
| Tu ruta · Asesoría · Productos | projects/rediseno-app-skandia/v1/index.html |
| Assets (logos, imágenes de login) | projects/rediseno-app-skandia/v1/assets/ |
